const breedEndpoint = "https://dog.ceo/api/breeds/list/all";
const breedTable = document.querySelector("#breed-table");
const breedStatus = document.querySelector("#breed-status");
const retryButton = document.querySelector("#breed-retry");
const breedFilter = document.querySelector("#breed-filter");
const groupSelect = document.querySelector("#breed-group");
const unclassified = "Not classified";
const groupKeys = {
  Herding: `australian/shepherd bouvier briard buhund/norwegian cattledog/australian collie/border
    corgi/cardigan entlebucher finnish/lapphund german/shepherd groenendael malinois pembroke
    rough/collie sheepdog/english sheepdog/shetland tervuren waterdog/spanish`,
  Hound: `basenji beagle bluetick borzoi coonhound dachshund deerhound/scottish elkhound/norwegian greyhound
    hound/afghan hound/basset hound/blood hound/english hound/ibizan hound/plott hound/walker
    otterhound redbone ridgeback/rhodesian saluki whippet wolfhound/irish`,
  "Non-Sporting": `bulldog/english bulldog/french chow cotondetulear dalmatian eskimo
    frise/bichon keeshond lhasa mexicanhairless poodle/miniature poodle/standard schipperke sharpei
    shiba terrier/boston terrier/tibetan`,
  Sporting: `clumber labrador pointer/german retriever/chesapeake retriever/curly retriever/flatcoated
    retriever/golden setter/english setter/gordon setter/irish spaniel/brittany spaniel/cocker
    spaniel/irish spaniel/sussex spaniel/welsh springer/english vizsla weimaraner`,
  Terrier: `airedale bullterrier/staffordshire schnauzer/miniature terrier/australian terrier/bedlington terrier/border
    terrier/cairn terrier/dandie terrier/fox terrier/irish terrier/kerryblue terrier/lakeland
    terrier/norfolk terrier/norwich terrier/russell terrier/scottish terrier/sealyham terrier/westhighland
    terrier/wheaten`,
  Toy: `affenpinscher chihuahua greyhound/italian havanese maltese papillon pekinese pinscher/miniature
    pomeranian poodle/toy pug shihtzu spaniel/blenheim spaniel/japanese terrier/silky terrier/toy
    terrier/yorkshire`,
  Working: `akita boxer dane/great danishswedish/farmdog doberman husky komondor kuvasz leonberg malamute
    mastiff/bull mastiff/english mastiff/tibetan mountain/bernese mountain/swiss newfoundland pyrenees
    rottweiler samoyed schnauzer/giant stbernard`,
};
const breedGroups = new Map();

for (const [group, keys] of Object.entries(groupKeys)) {
  for (const key of keys.split(/\s+/)) breedGroups.set(key, group);
}

for (const group of [...Object.keys(groupKeys), unclassified]) {
  groupSelect.add(new Option(group, group));
}

let directory = [];
let loading = false;

function renderBreeds() {
  const selectedGroup = groupSelect.value;
  const entries = selectedGroup ? directory.filter(({ group }) => group === selectedGroup) : directory;
  const rows = document.createDocumentFragment();

  for (const { breed, varieties, group } of entries) {
    const row = document.createElement("tr");
    const name = document.createElement("th");
    name.scope = "row";
    name.textContent = breed;

    const subBreeds = document.createElement("td");
    subBreeds.textContent = varieties.length ? varieties.join(", ") : "None listed";

    const groupCell = document.createElement("td");
    groupCell.textContent = group;
    row.append(name, subBreeds, groupCell);
    rows.append(row);
  }

  breedTable.tBodies[0].replaceChildren(rows);
  breedTable.hidden = entries.length === 0;
  if (!directory.length) {
    breedStatus.textContent = "No breeds are available right now.";
  } else if (!entries.length) {
    breedStatus.textContent = "No entries match this group.";
  } else {
    const count = selectedGroup ? `${entries.length} of ${directory.length}` : entries.length;
    breedStatus.textContent = `${count} directory ${directory.length === 1 ? "entry" : "entries"}`;
  }
}

async function loadBreeds() {
  if (loading || directory.length) return;

  loading = true;
  retryButton.hidden = true;
  breedStatus.textContent = "Loading breeds…";

  try {
    const response = await fetch(breedEndpoint);
    if (!response.ok) throw new Error(`Breed request failed: ${response.status}`);

    const { message, status } = await response.json();
    if (status !== "success" || !message || typeof message !== "object" || Array.isArray(message)) {
      throw new Error("Unexpected breed directory response");
    }

    const breeds = Object.entries(message).sort(([first], [second]) => first.localeCompare(second));
    directory = breeds.flatMap(([breed, varieties]) => {
      if (!varieties.length) {
        return [{ breed, varieties, group: breedGroups.get(breed) ?? unclassified }];
      }

      const varietiesByGroup = new Map();
      for (const variety of varieties) {
        const group = breedGroups.get(`${breed}/${variety}`) ?? unclassified;
        if (!varietiesByGroup.has(group)) varietiesByGroup.set(group, []);
        varietiesByGroup.get(group).push(variety);
      }

      return Array.from(varietiesByGroup, ([group, groupedVarieties]) => ({ breed, varieties: groupedVarieties, group }));
    });

    breedFilter.hidden = directory.length === 0;
    renderBreeds();
  } catch {
    breedStatus.textContent = "Couldn’t load the breed directory. Check your connection and try again.";
    retryButton.hidden = false;
  } finally {
    loading = false;
  }
}

for (const link of document.querySelectorAll('a[href="#breed-directory"]')) {
  link.addEventListener("click", (event) => {
    if (!event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) loadBreeds();
  });
}

function loadLinkedDirectory() {
  if (location.hash === "#breed-directory") loadBreeds();
}

retryButton.addEventListener("click", loadBreeds);
groupSelect.addEventListener("change", renderBreeds);
window.addEventListener("hashchange", loadLinkedDirectory);
loadLinkedDirectory();
